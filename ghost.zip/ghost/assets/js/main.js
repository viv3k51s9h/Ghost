

// create
let mm = gsap.matchMedia();

// add a media query. When it matches, the associated function will run
mm.add("(min-width: 800px)", () => {
    let tl = gsap.timeline({scrollTrigger: {
        trigger: ".second-section",
        start: "0% 100%",
        end: "50% 50%",
        scrub: "true",
        // markers: "true"
    }});
    
    tl.to('#ghost',{
    
    top: "90%",
    left: "0%",
    
    },'same-flow')
    tl.to('.halloween',{
    
        top: "145%",
        left: "6%",
        
        },'same-flow')
    
        tl.to('.rip',{
    
            top: "130%",
            left: "25%",
            rotate: "10deg",
            
            },'same-flow')
    
    tl.to('#g-text',{
    opacity:"0",
        },'same-flow')
    
        let tl2 = gsap.timeline({scrollTrigger: {
            trigger: ".second-three",
            start: "0% 100%",
            end: "50% 50%",
            scrub: "true",
            // markers: "true"
        }});
    
        tl2.to('#ghost',{
    
            top: "150%",
            left: "50%",
            scale: "2",
            
            }, 'same-flow2')
    
        tl2.to('.rip',{
    
            top: "190%",
            left: "75%",
            rotate: "0deg",
            }, 'same-flow2')
    
 
});

mm.add("(max-width: 799px)", () => {
    let tl = gsap.timeline({scrollTrigger: {
        trigger: ".second-section",
        start: "0% 100%",
        end: "50% 50%",
        scrub: "true",
        // markers: "true"
    }});
    
    tl.to('#ghost',{
    
    top: "90%",
    left: "0%",
    
    },'same-flow')
    tl.to('.halloween',{
    
        top: "145%",
        left: "6%",
        
        },'same-flow')
    
        tl.to('.rip',{
    
            top: "130%",
            left: "25%",
            rotate: "10deg",
            
            },'same-flow')
    
    tl.to('#g-text',{
    opacity:"0",
        },'same-flow')
    
        let tl2 = gsap.timeline({scrollTrigger: {
            trigger: ".second-three",
            start: "0% 100%",
            end: "50% 50%",
            scrub: "true",
            // markers: "true"
        }});
    
        tl2.to('#ghost',{
    
            top: "170%",
            left: "15%",
            
            }, 'same-flow2')
    
        tl2.to('.rip',{
    
            top: "190%",
            left: "75%",
            rotate: "0deg",
            }, 'same-flow2')
    
 
});